/* Frida Hook Script generated automatically for Resident Evil 4 Analysis */
if (ObjC.available) {
    try {
        // Hooking standard String initialization to intercept internal logic
        var NSString = ObjC.classes.NSString;
        Interceptor.attach(NSString["+ stringWithUTF8String:"].implementation, {
            onEnter: function (args) {
                var str = Memory.readUtf8String(args[2]);
                console.log("[RE4 Intercepted String]: " + str);
            }
        });
    } catch (err) {
        console.log("Exception in Hooking: " + err.message);
    }
} else {
    console.log("Objective-C Runtime is not available.");
}
